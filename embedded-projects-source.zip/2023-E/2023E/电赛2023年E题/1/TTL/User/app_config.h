#ifndef APP_CONFIG_H
#define APP_CONFIG_H 
#define HOME_PAN_DEG    (-5.7f)     // 舵机0：水平 
#define HOME_TILT_DEG   (10.2f)     // 舵机1：俯仰 

// 软限位 
#define PAN_MIN_DEG     (-90.0f)
#define PAN_MAX_DEG     ( 90.0f)
#define TILT_MIN_DEG    (-45.0f)
#define TILT_MAX_DEG    ( 45.0f)

#define PAN_SERVO_ID    0u
#define TILT_SERVO_ID   1u
#define HOME_MOVE_MS    800u        // 转到原点用的时间，越小越快 

// 串口微调步长（度）：2cm@1m 约 1.1 度，0.1 度足够细 
#define TRIM_STEP_DEG   0.1f

// 复位按键：PB1，上拉输入，按下为低电平。不接就设 ENABLE_HOME_KEY 0 
#define ENABLE_HOME_KEY 1
#define HOME_KEY_PORT   GPIOB
#define HOME_KEY_PIN    GPIO_Pin_1

// 声光提示 ：PB12 接有源蜂鸣器，PC13 是板载 LED（低电平亮）
#define ENABLE_PIEZO    0
#define PIEZO_PORT      GPIOB
#define PIEZO_PIN       GPIO_Pin_12

#endif
