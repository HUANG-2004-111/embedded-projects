#include "stm32f10x.h"
#include "usart.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "app_config.h"
#include <stdio.h>

Usart_DataTypeDef *servo_usart = &usart1;
Usart_DataTypeDef *pc_usart = &usart2;

static float pan_target = HOME_PAN_DEG;
static float tilt_target = HOME_TILT_DEG;
static volatile uint8_t cmd_char;        // 串口收到的最后一个字符 
static volatile uint8_t cmd_ready;

/* ------------------------------------------------------------------ */
/* 串口：printf 到 USART2，接收一个字符做命令                          */
/* ------------------------------------------------------------------ */
int fputc(int ch, FILE *f)
{
    while ((pc_usart->pUSARTx->SR & 0x40) == 0) { }
    USART_SendData(pc_usart->pUSARTx, (uint8_t)ch);
    return ch;
}

void USART2_IRQHandler(void)
{
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        cmd_char = (uint8_t)USART_ReceiveData(USART2);
        cmd_ready = 1;
    }
}

/* ------------------------------------------------------------------ */
/* 舵机                                                               */
/* ------------------------------------------------------------------ */
static float clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static void servo_output(float pan, float tilt, uint16_t ms)
{
    pan  = clampf(pan,  PAN_MIN_DEG,  PAN_MAX_DEG);
    tilt = clampf(tilt, TILT_MIN_DEG, TILT_MAX_DEG);
    FSUS_SetServoAngle(servo_usart, PAN_SERVO_ID,  pan,  ms, 0);
    FSUS_SetServoAngle(servo_usart, TILT_SERVO_ID, tilt, ms, 0);
}

static void go_home(void)
{
    pan_target  = HOME_PAN_DEG;
    tilt_target = HOME_TILT_DEG;
    servo_output(pan_target, tilt_target, HOME_MOVE_MS);
}

/* ------------------------------------------------------------------ */
/* 按键 / 显示                                                        */
/* ------------------------------------------------------------------ */
static void board_init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);

#if ENABLE_HOME_KEY
    gpio.GPIO_Pin   = HOME_KEY_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_IPU;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(HOME_KEY_PORT, &gpio);
#endif

    gpio.GPIO_Pin   = GPIO_Pin_13;         
    gpio.GPIO_Mode  = GPIO_Mode_Out_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpio);
    GPIO_SetBits(GPIOC, GPIO_Pin_13);

#if ENABLE_PIEZO
    gpio.GPIO_Pin   = PIEZO_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(PIEZO_PORT, &gpio);
    GPIO_ResetBits(PIEZO_PORT, PIEZO_PIN);
#endif
}

// OLED 显示一位小数，例如 "+10.2"、"-5.7" 
static void oled_fix1(uint8_t line, uint8_t col, float v)
{
    char buf[16];
    int32_t t = (int32_t)(v * 10.0f + (v >= 0.0f ? 0.5f : -0.5f));
    int32_t a = (t < 0) ? -t : t;
    sprintf(buf, "%s%d.%d", (t < 0) ? "-" : "+", (int)(a / 10), (int)(a % 10));
    OLED_ShowString(line, col, buf);
}

static void oled_status(void)
{
    OLED_ShowString(1, 1, "TASK1  HOME");
    OLED_ShowString(2, 1, "PAN ");
    oled_fix1(2, 5, pan_target);
    OLED_ShowString(3, 1, "TILT");
    oled_fix1(3, 5, tilt_target);
    OLED_ShowString(4, 1, "PB1=HOME");
}

static void print_state(void)
{
    int32_t p = (int32_t)(pan_target * 10.0f);
    int32_t t = (int32_t)(tilt_target * 10.0f);
    int32_t pa = (p < 0) ? -p : p;
    int32_t ta = (t < 0) ? -t : t;
    printf("PAN=%s%d.%d  TILT=%s%d.%d\r\n",
           (p < 0) ? "-" : "", (int)(pa / 10), (int)(pa % 10),
           (t < 0) ? "-" : "", (int)(ta / 10), (int)(ta % 10));
}

/* ------------------------------------------------------------------ */
/* 串口命令                                                           */
/* ------------------------------------------------------------------ */
static void handle_command(uint8_t c)
{
    if (c == '\r' || c == '\n' || c == ' ') 
		 return;

    if (c == 'a' || c == 'A') {
        pan_target -= TRIM_STEP_DEG;
    } else if (c == 'd' || c == 'D') {
        pan_target += TRIM_STEP_DEG;
    } else if (c == 'w' || c == 'W') {
        tilt_target += TRIM_STEP_DEG;
    } else if (c == 's' || c == 'S') {
        tilt_target -= TRIM_STEP_DEG;
    } else if (c == 'h' || c == 'H' || c == 'r' || c == 'R') {
        go_home();
        print_state();
        return;
    } else if (c == 'p' || c == 'P') {
        print_state();
        return;
    } else {
        return;
    }

    //微调时只动对应轴，200ms 转过去，方便盯着光斑一点点挪 
    pan_target  = clampf(pan_target,  PAN_MIN_DEG,  PAN_MAX_DEG);
    tilt_target = clampf(tilt_target, TILT_MIN_DEG, TILT_MAX_DEG);
    servo_output(pan_target, tilt_target, 200);
    print_state();
}

/* ------------------------------------------------------------------ */
int main(void)
{
    uint32_t tick = 0;

    SysTick_Init();
    Usart_Init();
    board_init();
    OLED_Init();

    OLED_ShowString(1, 1, "TASK1  HOME");
    OLED_ShowString(2, 1, "booting...");

    // 直接回原点（从任意位置慢慢转过去，不先甩到 0 度） 
    go_home();
    printf("\r\nE2023 basic-1 : home position\r\n");
    printf("a/d=pan -/+  w/s=tilt +/-  h=home  p=print\r\n");
    print_state();
    oled_status();

    while (1) 
	{
        if (cmd_ready) 
		  {
            uint8_t c = cmd_char;
            cmd_ready = 0;
            handle_command(c);
            oled_status();
            tick = 0;
        }

#if ENABLE_HOME_KEY
        if (GPIO_ReadInputDataBit(HOME_KEY_PORT, HOME_KEY_PIN) == 0) 
		  {
            SysTick_DelayMs(20);                            // 消抖 
            if (GPIO_ReadInputDataBit(HOME_KEY_PORT, HOME_KEY_PIN) == 0) 
				{
                go_home();
                print_state();
                oled_status();
                while (GPIO_ReadInputDataBit(HOME_KEY_PORT, HOME_KEY_PIN) == 0) 
					 {
                    SysTick_DelayMs(10);                 
                }
                tick = 0;
            }
        }
#endif

        // 每 200ms 刷一次屏 
        if (++tick >= 20) 
		  {
            tick = 0;
            oled_status();
        }
        SysTick_DelayMs(10);
    }
}
