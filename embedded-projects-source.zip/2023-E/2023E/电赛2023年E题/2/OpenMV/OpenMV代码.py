import sensor
import time
import image
from machine import UART  # 导入串口模块

# 初始化串口通信（根据实际接线选择UART端口和波特率）
# OpenMV H7 Plus使用UART3，P4(TX)和P5(RX)
uart = UART(3, baudrate=115200, timeout_char=1000)

# 摄像头初始化
sensor.reset()
sensor.set_pixformat(sensor.RGB565)                         # 使用RGB565彩色模式
sensor.set_vflip(True)                                      # 垂直翻转
sensor.set_hmirror(True)                                    # 水平镜像
sensor.set_framesize(sensor.QVGA)                           # 设置为QVGA分辨率

sensor.set_brightness(-3)                                   # 降低亮度
sensor.set_contrast(3)                                      # 提高对比度
sensor.set_auto_exposure(False, exposure_us=120000)         # 手动设置曝光
sensor.skip_frames(time=2000)                               # 等待摄像头稳定

clock = time.clock()

# 绘制矩形函数
def draw_rectangle(corners, color):
    """在图像上绘制矩形，corners为矩形的四个顶点"""
    img.draw_line(corners[0][0], corners[0][1], corners[1][0], corners[1][1], color, 2)
    img.draw_line(corners[1][0], corners[1][1], corners[2][0], corners[2][1], color, 2)
    img.draw_line(corners[2][0], corners[2][1], corners[3][0], corners[3][1], color, 2)
    img.draw_line(corners[3][0], corners[3][1], corners[0][0], corners[0][1], color, 2)

# 发送矩形宽度和高度
def send_width_height_to_stm32(width, height):
    data = bytearray([0x3C])   # 帧头
    data.append(width >> 8)    # 宽度高8位
    data.append(width & 0xFF)  # 宽度低8位
    data.append(height >> 8)   # 高度高8位
    data.append(height & 0xFF) # 高度低8位
    data.append(0x6B)          # 帧尾
    uart.write(data)

# 发送坐标数据
def send_coordinates_to_stm32(corners):
    data = bytearray([0x2C])            # 帧头
    for point in corners:
        data.append(point[0] >> 8)      # X高8位
        data.append(point[0] & 0xFF)    # X低8位
        data.append(point[1] >> 8)      # Y高8位
        data.append(point[1] & 0xFF)    # Y低8位
    data.append(0x5B)                   # 帧尾
    uart.write(data)


# 主循环
while True:
    clock.tick()
    img = sensor.snapshot()

    # 寻找矩形
    rect_detected = False  # 标记是否检测到有效矩形
    for r in img.find_rects(threshold=100):
        # 过滤较小的矩形，magnitude值表示矩形的大小
        if r.magnitude() > 50000:
            corners = r.corners()

            # 获取矩形的边界框信息
            x, y, width_pixels, height_pixels = r.rect()

            # 打印矩形的宽度和高度
            print(f"标定物体宽度: {width_pixels} 像素")
            print(f"标定物体高度: {height_pixels} 像素")

            # 发送宽度和高度
            send_width_height_to_stm32(width_pixels, height_pixels)

            # 绘制矩形边框和角点
            draw_rectangle(corners, color=(255, 0, 0))              # 红色边框
            for p in corners:
                img.draw_circle(p[0], p[1], 5, color=(0, 255, 0))   # 绿色角点

            # 发送坐标
            send_coordinates_to_stm32(corners)

            rect_detected = True
            # 打印调试信息
            print("矩形大小:", r.magnitude())
            print("矩形角坐标:", corners)
            break  # 只处理第一个符合条件的矩形

    # 如果未检测到矩形，发送空数据帧
    if not rect_detected:
        uart.write("NO_RECT#\n".encode())

    # 显示帧率
    img.draw_string(10, 10, f"FPS: {clock.fps():.2f}", color=(0, 255, 0))
    time.sleep_ms(100)  # 控制发送频率，避免数据拥堵
