#include "stm32f10x.h"
#include "usart.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"

#define RX_BUFFER_SIZE 64
// 存储4个点的坐标（每个点包含x和y）
uint16_t points[4][2] = {0};  // points[0][0] = 第1点x, points[0][1] = 第1点y...
uint8_t point_group_received = 0;  // 一组4点接收完成标志
char RxBuffer[RX_BUFFER_SIZE];     // 接收缓冲区
volatile uint8_t RxIndex = 0;      // 缓冲区索引
volatile uint8_t data_received = 0;// 单帧数据接收完成标志

// 串口接收状态机
typedef enum 
{
    STATE_WAIT_HEADER,          // 等待帧头(0x2C)
    STATE_RECEIVE_DATA,         // 接收4点坐标数据(16字节)
    STATE_WAIT_TAIL             // 等待帧尾(0x5B)
} ReceiveState;
ReceiveState state = STATE_WAIT_HEADER;

// 屏幕中心坐标(QVGA 320x240)
#define SCREEN_CENTER_X 160
#define SCREEN_CENTER_Y 120

// 舵机角度限制
#define HORIZONTAL_MIN_ANGLE -90
#define HORIZONTAL_MAX_ANGLE 90
#define VERTICAL_MIN_ANGLE -45
#define VERTICAL_MAX_ANGLE 45

// 舵机控制端口(串口1)和日志端口(串口2)
Usart_DataTypeDef* servo_usart = &usart1;
Usart_DataTypeDef* logging_usart = &usart2;

// printf重定向到串口2（调试用）
int fputc(int ch, FILE *f) {
    while((logging_usart->pUSARTx->SR & 0X40) == 0);
    USART_SendData(logging_usart->pUSARTx, (uint8_t)ch);
    return ch;
}

// 串口2中断服务函数(自动触发)
void USART2_IRQHandler(void) {
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        uint8_t received = USART_ReceiveData(USART2);

        switch (state) {
            case STATE_WAIT_HEADER:
                // 检测到帧头(0x2C)，开始接收4点数据
                if (received == 0x2C) {
                    state = STATE_RECEIVE_DATA;
                    RxIndex = 0;  // 重置缓冲区索引
                }
                break;

            case STATE_RECEIVE_DATA:
                // 检测到帧尾(0x5B)，标记单帧数据接收完成
                if (received == 0x5B) {
                    state = STATE_WAIT_TAIL;
                    data_received = 1;  // 单帧完成标志
                } else {
                    // 数据存入缓冲区(最多存16字节，对应4个点)
                    if (RxIndex < 16 && RxIndex < RX_BUFFER_SIZE - 1) {
                        RxBuffer[RxIndex++] = received;
                    }
                }
                break;

            case STATE_WAIT_TAIL:
                // 帧尾处理完成，回到等待帧头状态
                state = STATE_WAIT_HEADER;
                break;
        }
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);  // 清除中断标志
    }
}

// 解析4个点的坐标数据（适配OpenMV的发送格式）
void Process_Received_Data(void) {
    if (data_received) {
        // 有效数据应为16字节（4个点×每个点4字节：x高+ x低+ y高+ y低）
        if (RxIndex == 16) {
            // 解析4个点的坐标
            for (uint8_t i = 0; i < 4; i++) {
                uint8_t base_idx = i * 4;  // 每个点占4字节，计算起始索引
                // 合成x坐标（高8位+低8位）
                points[i][0] = (RxBuffer[base_idx] << 8) | RxBuffer[base_idx + 1];
                // 合成y坐标（高8位+低8位）
                points[i][1] = (RxBuffer[base_idx + 2] << 8) | RxBuffer[base_idx + 3];
            }
            point_group_received = 1;  // 标记4点组接收完成
            printf("解析4点坐标完成:\n");
            for (uint8_t i = 0; i < 4; i++) {
                printf("P%d: X=%d, Y=%d\n", i+1, points[i][0], points[i][1]);
            }
        } else {
            // 数据长度异常，重置标志
            point_group_received = 0;
            printf("数据长度异常: 实际%d字节，期望16字节\n", RxIndex);
        }
        // 重置接收状态
        data_received = 0;
        RxIndex = 0;
        state = STATE_WAIT_HEADER;
    }
}

// 坐标转舵机角度
void ConvertCoordinatesToAngles(int16_t x, int16_t y, float *h_angle, float *v_angle) 
{
    int16_t dx = x - SCREEN_CENTER_X;  // X方向偏差
    int16_t dy = y - SCREEN_CENTER_Y;  // Y方向偏差

    // 映射偏差到角度（水平-90~90°，垂直-45~45°）
    *h_angle = (float)dx / SCREEN_CENTER_X * HORIZONTAL_MAX_ANGLE;
    *v_angle = (float)dy / SCREEN_CENTER_Y * VERTICAL_MAX_ANGLE;

    // 角度限幅（保护舵机）
    *h_angle = (*h_angle < HORIZONTAL_MIN_ANGLE) ? HORIZONTAL_MIN_ANGLE : *h_angle;
    *h_angle = (*h_angle > HORIZONTAL_MAX_ANGLE) ? HORIZONTAL_MAX_ANGLE : *h_angle;
    *v_angle = (*v_angle < VERTICAL_MIN_ANGLE) ? VERTICAL_MIN_ANGLE : *v_angle;
    *v_angle = (*v_angle > VERTICAL_MAX_ANGLE) ? VERTICAL_MAX_ANGLE : *v_angle;
}

int main(void) {
    // 初始化外设
    SysTick_Init();
    Usart_Init();        // 初始化串口1(舵机)和串口2(日志)
    OLED_Init();         // 初始化OLED屏幕
    printf("系统初始化完成，等待OpenMV发送4点坐标...\n");

    // 使能串口2接收中断（自动接收OpenMV数据）
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    float h_angle = 0, v_angle = 0;  // 舵机角度
    uint16_t interval = 500;         // 单个点的转动时间(ms)
    uint16_t power = 0;              // 舵机功率
    uint8_t processing = 0;          // 标记是否正在处理一组点

    while (1) {
        Process_Received_Data();  // 解析接收到的4点数据

        // 若接收到完整的4点组，且未在处理中，则开始控制舵机
        if (point_group_received && !processing) 
		{
            processing = 1;  // 标记开始处理
            OLED_Clear();    // 清屏，显示新组数据

            // 循环控制舵机移动到4个点
            for (uint8_t i = 0; i < 4; i++) 
			{
                // 显示当前点信息
                OLED_ShowString(1, 1, "Point:");
                OLED_ShowNum(1, 7, i+1, 1);  // 显示第几个点
                OLED_ShowString(2, 1, "X:");
                OLED_ShowNum(2, 3, points[i][0], 3);  // X坐标
                OLED_ShowString(3, 1, "Y:");
                OLED_ShowNum(3, 3, points[i][1], 3);  // Y坐标

                // 坐标转角度
                ConvertCoordinatesToAngles(points[i][0], points[i][1], &h_angle, &v_angle);

                // 显示角度
                OLED_ShowString(4, 1, "H:");
                OLED_ShowSignedNum(4, 3, (int16_t)h_angle, 3);  // 水平角度
                OLED_ShowString(4, 8, "V:");
                OLED_ShowSignedNum(4, 10, (int16_t)v_angle, 3); // 垂直角度

                // 控制舵机转动到当前点
                FSUS_SetServoAngle(servo_usart, 0, h_angle, interval, power);  // 水平舵机
                FSUS_SetServoAngle(servo_usart, 1, -v_angle, interval, power); // 垂直舵机
                printf("移动到P%d: 水平=%.1f°, 垂直=%.1f°\n", i+1, h_angle, v_angle);

                SysTick_DelayMs(interval + 500);  // 等待转动完成+停留500ms
            }

            // 4个点处理完成，重置状态
            point_group_received = 0;
            processing = 0;
            OLED_Clear();
            OLED_ShowString(2, 1, "完成一组点");
            printf("4个点处理完成，等待下一组...\n");
        }

        SysTick_DelayMs(50);  // 降低CPU占用
    }
}