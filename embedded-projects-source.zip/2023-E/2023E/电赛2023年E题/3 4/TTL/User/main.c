#include "stm32f10x.h"
#include "usart.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "Button.h"  // 引用Button头文件，获取全局变量声明
#define   RX_BUFFER_SIZE 80

// 定义接收缓冲区大小
uint16_t xx[8],yy[8];
char RxBuffer[RX_BUFFER_SIZE];  // 接收数据的缓冲区
volatile uint8_t RxIndex = 0;   // 接收数据的索引

// 串口接收状态机定义
typedef enum 
{
    STATE_WAIT_HEADER,          //等待帧头
    STATE_RECEIVE_WIDTH,        // 接收宽度数据
    STATE_RECEIVE_HEIGHT,       // 接收高度数据
    STATE_WAIT_SECOND_HEADER,   // 等待第二个帧头
    STATE_RECEIVE_DATA,         // 接收数据部分
    STATE_WAIT_TAIL           // 等待帧尾
} ReceiveState;

ReceiveState state = STATE_WAIT_HEADER;   // 当前接收状态
uint8_t data_received = 0;    // 接受完数据帧标志位
uint16_t CALIB_OBJECT_WIDTH_PIXEL;  // A4纸在图像中的宽度（像素）
uint16_t CALIB_OBJECT_HEIGHT_PIXEL; // A4纸在图像中的高度（像素）

// 屏幕尺寸和中心坐标
#define SCREEN_WIDTH  320
#define SCREEN_HEIGHT 240
#define SCREEN_CENTER_X (SCREEN_WIDTH / 2)   // 中心X = 160
#define SCREEN_CENTER_Y (SCREEN_HEIGHT / 2)  // 中心Y = 120

// 舵机角度限制（根据实际舵机调整）
#define HORIZONTAL_MIN_ANGLE -90  // 水平最小角度（左极限）
#define HORIZONTAL_MAX_ANGLE 90   // 水平最大角度（右极限）
#define VERTICAL_MIN_ANGLE -45    // 垂直最小角度（下极限）
#define VERTICAL_MAX_ANGLE 45     // 垂直最大角度（上极限）
// 使用串口1作为舵机控制的端口
// <接线说明>
// STM32F103 PA9(Tx)    <----> 总线伺服舵机转接板 Rx
// STM32F103 PA10(Rx)   <----> 总线伺服舵机转接板 Tx
// STM32F103 GND        <----> 总线伺服舵机转接板 GND
// STM32F103 V5         <----> 总线伺服舵机转接板 5V9
// <注意事项>
// 使用前确保已设置usart.h里面的USART1_ENABLE为1
Usart_DataTypeDef* servo_usart = &usart1; 

// 使用串口2作为日志输出的端口
// <接线说明>
// STM32F103 PA2(Tx) <----> USB转TTL Rx
// STM32F103 PA3(Rx) <----> USB转TTL Tx
// STM32F103 GND     <----> USB转TTL GND
// STM32F103 V5      <----> USB转TTL 5V (可选)
Usart_DataTypeDef* logging_usart = &usart2;

// 重定向c库函数printf到串口，重定向后可使用printf函数
int fputc(int ch, FILE *f)
{
    while((logging_usart->pUSARTx->SR&0X40)==0){}
    /* 发送一个字节数据到串口 */
    USART_SendData(logging_usart->pUSARTx, (uint8_t) ch);
    /* 等待发送完毕 */
    // while (USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET);       
    return (ch);
}
// 串口接收中断处理函数
// 串口接收中断处理函数
void USART2_IRQHandler(void) 
{
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) 
    {
        uint8_t received = USART_ReceiveData(USART2);  // 接收数据

        switch (state)
        {
            case STATE_WAIT_HEADER:      // 等待第一个帧头 0x3C
                if (received == 0x3c) 
                {  // 检测到第一个帧头
                    state = STATE_RECEIVE_WIDTH; // 设置状态为开始接收宽度数据
                    RxIndex = 0;
                }
                break;

            case STATE_RECEIVE_WIDTH:    // 接收宽度数据
                if (RxIndex == 0) {
                    CALIB_OBJECT_WIDTH_PIXEL = received ;
                } else if (RxIndex == 1) {
                    CALIB_OBJECT_WIDTH_PIXEL |= received;
                    state = STATE_RECEIVE_HEIGHT; // 设置状态为开始接收高度数据
                }
                RxIndex++;
                break;

            case STATE_RECEIVE_HEIGHT:   // 接收高度数据
                if (RxIndex == 2) {
                    CALIB_OBJECT_HEIGHT_PIXEL = received ;
                } else if (RxIndex == 3) {
                    CALIB_OBJECT_HEIGHT_PIXEL |= received;
                    state = STATE_WAIT_SECOND_HEADER; // 设置状态为等待第二个帧头 0x2C
                    RxIndex = 0;
                }
                RxIndex++;
                break;

            case STATE_WAIT_SECOND_HEADER: // 等待第二个帧头 0x2C
                if (received == 0x2C) 
                {  // 检测到第二个帧头
                    state = STATE_RECEIVE_DATA; // 设置状态为开始接收四个坐标数据
                    RxIndex = 0;
                }
                break;

            case STATE_RECEIVE_DATA:     // 开始接收四个坐标数据
                if (received == 0x5B) 
                {  // 检测到第二个帧尾
                    state = STATE_WAIT_TAIL; //设置状态为等待帧尾
                    data_received = 1;   // 接收完数据标志位置1
                    
                } 
                else 
                {
                    if (RxIndex < RX_BUFFER_SIZE - 1) 
                    {
                        RxBuffer[RxIndex++] = received;  // 如果接收到的数据不是帧尾，那就一直把数据存在缓冲区里
                    }
                }
                break;

                case STATE_WAIT_TAIL:           //接收到等待帧尾就重新设置为等待帧头，如此循环接收
                if (received == 0x5B) {
                    state = STATE_WAIT_HEADER; 
                } else {
                    state = STATE_WAIT_HEADER;
                }
                break;
        }
    }
}

// 处理接收到的数据
void Process_Received_Data(void) 
{
    if (data_received) 
    {
        if (RxIndex >= 16) 
        {  // 4个点 × 每个点4字节 = 16字节
            for (int i = 0; i < 4; i++) 
            {  // 4个角点
                int base = i * 4;          // 每个点占4字节
                // 解析x坐标（2字节合成）
                xx[i] = (RxBuffer[base] << 8) | RxBuffer[base + 1];
                // 解析y坐标（2字节合成）
                yy[i] = (RxBuffer[base + 2] << 8) | RxBuffer[base + 3];
            }
        }
        // 重置状态
        data_received = 0;
        RxIndex = 0;
        state = STATE_WAIT_HEADER;
    }
}

// 标定参数（通过实际测量确定）
#define CALIB_OBJECT_WIDTH_CM    23.0f  // A4纸宽度（cm）
#define CALIB_OBJECT_HEIGHT_CM   31.7f  // A4纸高度（cm）

// 计算比例因子
#define SCALE_X (CALIB_OBJECT_WIDTH_PIXEL / CALIB_OBJECT_WIDTH_CM)  // 像素/cm
#define SCALE_Y (CALIB_OBJECT_HEIGHT_PIXEL / CALIB_OBJECT_HEIGHT_CM)  // 像素/cm

// 摄像头和激光笔的位置偏差（像素单位）
#define CAMERA_LASER_OFFSET_X (0.2f * SCALE_X)  // 水平方向偏差（像素）
#define CAMERA_LASER_OFFSET_Y (5.0f * SCALE_Y)  // 垂直方向偏差（像素）

// 坐标转角度函数
void ConvertCoordinatesToAngles(int16_t x, int16_t y, float *h_angle, float *v_angle) 
{
    // 考虑摄像头和激光笔的位置偏差
    int16_t adjusted_x = x - CAMERA_LASER_OFFSET_X;
    int16_t adjusted_y = y - CAMERA_LASER_OFFSET_Y;

    // 计算相对于中心的坐标偏差
    int16_t dx = adjusted_x - SCREEN_CENTER_X;
    int16_t dy = adjusted_y - SCREEN_CENTER_Y;
    
    // 线性映射：将坐标偏差转换为舵机角度
    *h_angle = (float)dx / SCREEN_CENTER_X * HORIZONTAL_MAX_ANGLE;
    *v_angle = (float)dy / SCREEN_CENTER_Y * VERTICAL_MAX_ANGLE;
    
    // 角度限幅保护
    if (*h_angle < HORIZONTAL_MIN_ANGLE) *h_angle = HORIZONTAL_MIN_ANGLE;
    if (*h_angle > HORIZONTAL_MAX_ANGLE) *h_angle = HORIZONTAL_MAX_ANGLE;
    if (*v_angle < VERTICAL_MIN_ANGLE)   *v_angle = VERTICAL_MIN_ANGLE;
    if (*v_angle > VERTICAL_MAX_ANGLE)   *v_angle = VERTICAL_MAX_ANGLE;
}
// 舵机控制相关的参数
// 运行时间ms  
// 可以尝试修改设置更小的运行时间，例如500ms
uint16_t interval = 300;
// 舵机执行功率 单位mV 默认为0   
uint16_t power = 0;

int main(void)
{
    int i;
    // 系统初始化
    SysTick_Init();
    Usart_Init();
    OLED_Init();
    Button_Init();  // 初始化按钮中断
    
    while (1)
    {
        Process_Received_Data();  // 处理串口数据
        
        // 调用按钮计时处理函数
    

        // 遍历4个点，控制舵机
        for (i = 0; i <= 3; i++)
        {
            float h_angle, v_angle;
            ConvertCoordinatesToAngles(xx[i], yy[i], &h_angle, &v_angle);
            // 基础角度（坐标转换）
            float base_servo0 = (h_angle * 7) / 12 - 5.65f;
            float base_servo1 = -(v_angle * 0.7f - 10.2f);
            // 最终角度 = 基础角度 + 中断偏移量
            float final_servo0 = base_servo0 + servo0_angle;
            float final_servo1 = base_servo1 + servo1_angle;           
            // 限幅保护
          //  if (final_servo0 < -90.0f)  final_servo0 = -90.0f;
          //  if (final_servo0 > 90.0f)   final_servo0 = 90.0f;
          //  if (final_servo1 < -45.0f)  final_servo1 = -45.0f;
          //  if (final_servo1 > 45.0f)   final_servo1 = 45.0f;           
            // 控制舵机
            FSUS_SetServoAngle(servo_usart, 0, final_servo0, 800, power);
            FSUS_SetServoAngle(servo_usart, 1, final_servo1, 800, power);     
           // OLED_ShowNum(1, 1, CALIB_OBJECT_WIDTH_PIXEL,5);
           // OLED_ShowNum(2, 1, CALIB_OBJECT_HEIGHT_PIXEL,5);
            OLED_ShowNum(3, 1, servo0_angle,5);
            OLED_ShowNum(4, 1, servo1_angle,5);    
          //  OLED_ShowNum(1, 10, "servo0_angle");
          //  OLED_ShowNum(2, 10, "servo1_angle");                            
            SysTick_DelayMs(1200);
        }
    }
}