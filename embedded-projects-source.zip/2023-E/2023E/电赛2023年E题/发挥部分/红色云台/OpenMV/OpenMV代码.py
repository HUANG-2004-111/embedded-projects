# 靶纸四角识别 - OpenMV
#
# 用 find_rects 找屏幕上 A4 靶纸四周的黑色电工胶带，取四个角点，
# 按 23 字节定长帧发给 STM32（UART3，P4=TX，P5=RX，115200）。
#
# 帧格式：
#   3C | WH WL | HH HL | 2C | x0H x0L y0H y0L | ... | x3H x3L y3H y3L | 5B
# W/H 是外接矩形的像素宽高，STM32 用它换算像素/厘米的比例。
# 宽高在 STM32 端按单字节处理，所以画面里靶纸的宽、高都要小于 256 像素，
# 相机取景时别让靶纸占满整幅画面。

import sensor
import time
from pyb import UART

# 串口
UART_ID = 3
UART_BAUD = 115200

# 图像
VFLIP = True
HMIRROR = True
BRIGHTNESS = -3
CONTRAST = 3
EXPOSURE_US = 120000
SEND_PERIOD_MS = 80

# 矩形检测
RECT_THRESHOLD = 100
MAGNITUDE_MIN = 50000
REVERSE_CORNERS = False     # 走的方向反了改成 True

uart = UART(UART_ID, UART_BAUD, bits=8, parity=None, stop=1,
            timeout=50, timeout_char=2)


def put_u16(buf, index, value):
    value = int(value) & 0xFFFF
    buf[index] = (value >> 8) & 0xFF
    buf[index + 1] = value & 0xFF


def send_rect(corners, w, h):
    pkt = bytearray(23)

    pkt[0] = 0x3C
    put_u16(pkt, 1, w)
    put_u16(pkt, 3, h)
    pkt[5] = 0x2C

    idx = 6
    for p in corners:
        put_u16(pkt, idx, p[0])
        put_u16(pkt, idx + 2, p[1])
        idx += 4

    pkt[22] = 0x5B
    uart.write(pkt)


def main():
    sensor.reset()
    sensor.set_pixformat(sensor.RGB565)
    sensor.set_framesize(sensor.QVGA)
    sensor.set_vflip(VFLIP)
    sensor.set_hmirror(HMIRROR)
    sensor.skip_frames(time=1000)
    sensor.set_brightness(BRIGHTNESS)
    sensor.set_contrast(CONTRAST)
    sensor.set_auto_exposure(False, exposure_us=EXPOSURE_US)
    sensor.skip_frames(time=300)

    clock = time.clock()

    while True:
        clock.tick()
        img = sensor.snapshot()
        found = False

        for r in img.find_rects(threshold=RECT_THRESHOLD):
            if r.magnitude() < MAGNITUDE_MIN:
                continue

            corners = list(r.corners())
            if REVERSE_CORNERS:
                corners.reverse()

            w = r.rect()[2]
            h = r.rect()[3]
            send_rect(corners, w, h)
            found = True

            for i in range(4):
                p = corners[i]
                q = corners[(i + 1) % 4]
                img.draw_line(p[0], p[1], q[0], q[1], color=(255, 0, 0), size=2)
                img.draw_circle(p[0], p[1], 4, color=(0, 255, 0))

            break       # 只取第一个满足条件的矩形

        if not found:
            img.draw_string(2, 2, "NO RECT", color=(255, 0, 0))

        img.draw_string(2, 12, "%d fps" % int(clock.fps()), color=(255, 255, 0))
        time.sleep_ms(SEND_PERIOD_MS)


main()
