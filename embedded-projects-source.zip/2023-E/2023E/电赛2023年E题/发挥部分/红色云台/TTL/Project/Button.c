#include "Button.h"  // ����ͷ�ļ�

// ȫ�ֱ�������
uint8_t selected_servo = 0;        // ѡ��Ķ��(0/1)
float servo0_angle = 0.0f;         // ���0�Ƕ�ƫ����
float servo1_angle = 0.0f;         // ���1�Ƕ�ƫ����

// ������ʱ��־�ͼ�ʱ������
uint8_t button2_timer_start = 0;
uint8_t button3_timer_start = 0;
uint8_t button4_timer_start = 0;
uint8_t button5_timer_start = 0;
uint16_t button2_timer_cnt = 0;
uint16_t button3_timer_cnt = 0;
uint16_t button4_timer_cnt = 0;
uint16_t button5_timer_cnt = 0;

// ��ʼ���ⲿ�ж�
void Button_Init(void) 
{
    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // ʹ��GPIO��AFIOʱ��
    RCC_APB2PeriphClockCmd(BUTTON_RCC | RCC_APB2Periph_AFIO, ENABLE);

    // ���ð�������Ϊ��������
    GPIO_InitStructure.GPIO_Pin = BUTTON1_PIN | BUTTON2_PIN | BUTTON3_PIN | BUTTON4_PIN | BUTTON5_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(BUTTON_PORT, &GPIO_InitStructure);

    // �����ⲿ�ж���3 (PB3)
    GPIO_EXTILineConfig(BUTTON_EXTI_PORT, GPIO_PinSource3);
    EXTI_InitStructure.EXTI_Line = BUTTON1_EXTI_LINE;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  // �����ش���
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    // �����ⲿ�ж���4 (PB4)
    GPIO_EXTILineConfig(BUTTON_EXTI_PORT, GPIO_PinSource4);
    EXTI_InitStructure.EXTI_Line = BUTTON2_EXTI_LINE;
    EXTI_Init(&EXTI_InitStructure);

    // �����ⲿ�ж���5-7 (PB5-PB7)
    GPIO_EXTILineConfig(BUTTON_EXTI_PORT, GPIO_PinSource5);
    EXTI_InitStructure.EXTI_Line = BUTTON3_EXTI_LINE;
    EXTI_Init(&EXTI_InitStructure);

    GPIO_EXTILineConfig(BUTTON_EXTI_PORT, GPIO_PinSource6);
    EXTI_InitStructure.EXTI_Line = BUTTON4_EXTI_LINE;
    EXTI_Init(&EXTI_InitStructure);

    GPIO_EXTILineConfig(BUTTON_EXTI_PORT, GPIO_PinSource7);
    EXTI_InitStructure.EXTI_Line = BUTTON5_EXTI_LINE;
    EXTI_Init(&EXTI_InitStructure);

    // ����NVIC - �ж���3
    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    // ����NVIC - �ж���4
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_Init(&NVIC_InitStructure);

    // ����NVIC - �ж���5-9
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_Init(&NVIC_InitStructure);
}

// �ⲿ�ж�3�������� (PB3) - ѡ����0/1�л�
void EXTI3_IRQHandler(void) 
{
    if(EXTI_GetITStatus(BUTTON1_EXTI_LINE) != RESET) {
        // ������ʱ
        for(volatile int i = 0; i < 10000; i++);
        
        // ��鰴���Ƿ���Ȼ����
        if(GPIO_ReadInputDataBit(BUTTON_PORT, BUTTON1_PIN) == SET) 
        {
            // �л����ѡ��״̬
            selected_servo = !selected_servo;
        }
        
        // ����жϱ�־λ
        EXTI_ClearITPendingBit(BUTTON1_EXTI_LINE);
    }
}

// �ⲿ�ж�4�������� (PB4) - ���0�Ƕ�����
void EXTI4_IRQHandler(void) 
{
    if(EXTI_GetITStatus(BUTTON2_EXTI_LINE) != RESET) 
    {
        if (!button2_timer_start) {
            button2_timer_start = 1;
            button2_timer_cnt = 0;
        }
        EXTI_ClearITPendingBit(BUTTON2_EXTI_LINE);

        // 500msȷ��
        if (button2_timer_start) {
            if (GPIO_ReadInputDataBit(BUTTON_PORT, BUTTON2_PIN) == SET) {
                button2_timer_cnt++;
                if (button2_timer_cnt >= 500) { // 500ms
                    button2_timer_start = 0;
                    button2_timer_cnt = 0;

                    // ���0�Ƕ�����
                    servo0_angle += ANGLE_STEP;
                    if (servo0_angle > MAX_ANGLE) servo0_angle = MAX_ANGLE;
                }
            } else {
                button2_timer_start = 0;
                button2_timer_cnt = 0;
            }
        }
    }
}

// �ⲿ�ж�5-9�������� (PB5-PB7)
void EXTI9_5_IRQHandler(void)    
{
    // PB5 - ���0�Ƕȼ���
    if(EXTI_GetITStatus(BUTTON3_EXTI_LINE) != RESET) 
    {
        if (!button3_timer_start) {
            button3_timer_start = 1;
            button3_timer_cnt = 0;
        }
        EXTI_ClearITPendingBit(BUTTON3_EXTI_LINE);

        if (button3_timer_start) {
            if (GPIO_ReadInputDataBit(BUTTON_PORT, BUTTON3_PIN) == SET) {
                button3_timer_cnt++;
                if (button3_timer_cnt >= 500) { // 500ms
                    button3_timer_start = 0;
                    button3_timer_cnt = 0;

                    // ���0�Ƕȼ���
                    servo0_angle -= ANGLE_STEP;
                    if (servo0_angle < MIN_ANGLE) servo0_angle = MIN_ANGLE;
                }
            } else {
                button3_timer_start = 0;
                button3_timer_cnt = 0;
            }
        }
    }
    
    // PB6 - ���1�Ƕ�����
    if(EXTI_GetITStatus(BUTTON4_EXTI_LINE) != RESET) 
    {
        if (!button4_timer_start) {
            button4_timer_start = 1;
            button4_timer_cnt = 0;
        }
        EXTI_ClearITPendingBit(BUTTON4_EXTI_LINE);

        if (button4_timer_start) {
            if (GPIO_ReadInputDataBit(BUTTON_PORT, BUTTON4_PIN) == SET) {
                button4_timer_cnt++;
                if (button4_timer_cnt >= 500) { // 500ms
                    button4_timer_start = 0;
                    button4_timer_cnt = 0;

                    // ���1�Ƕ�����
                    servo1_angle += ANGLE_STEP;
                    if (servo1_angle > MAX_ANGLE) servo1_angle = MAX_ANGLE;
                }
            } else {
                button4_timer_start = 0;
                button4_timer_cnt = 0;
            }
        }
    }
    
    // PB7 - ���1�Ƕȼ���
    if(EXTI_GetITStatus(BUTTON5_EXTI_LINE) != RESET) {
        if (!button5_timer_start) {
            button5_timer_start = 1;
            button5_timer_cnt = 0;
        }
        EXTI_ClearITPendingBit(BUTTON5_EXTI_LINE);

        if (button5_timer_start) {
            if (GPIO_ReadInputDataBit(BUTTON_PORT, BUTTON5_PIN) == SET) {
                button5_timer_cnt++;
                if (button5_timer_cnt >= 500) { // 500ms
                    button5_timer_start = 0;
                    button5_timer_cnt = 0;

                    // ���1�Ƕȼ���
                    servo1_angle -= ANGLE_STEP;
                    if (servo1_angle < MIN_ANGLE) servo1_angle = MIN_ANGLE;
                }
            } else {
                button5_timer_start = 0;
                button5_timer_cnt = 0;
            }
        }
    }
}
