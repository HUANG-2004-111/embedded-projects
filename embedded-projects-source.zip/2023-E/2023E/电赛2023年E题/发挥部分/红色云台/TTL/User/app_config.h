#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/*
 * 红色云台参数配置
 *
 * 舵机行程、原点角度、巡边节奏、按键都在这里改。
 */

/* ---------------- 舵机 ---------------- */

#define PAN_SERVO_ID      0u
#define TILT_SERVO_ID     1u

#define PAN_MIN_DEG       (-90.0f)
#define PAN_MAX_DEG       ( 90.0f)
#define TILT_MIN_DEG      (-45.0f)
#define TILT_MAX_DEG      ( 45.0f)

/* 光斑落在屏幕原点时两个舵机的角度，按现场标定值填 */
#define HOME_PAN_DEG      (-5.7f)
#define HOME_TILT_DEG     (10.2f)
#define HOME_MOVE_MS      800u

/* 每段 800ms 转过去，停 1200ms，四个角走完约 10s */
#define TRACE_MOVE_MS     800u
#define TRACE_DWELL_MS    1200u

/* ---------------- 按键 ---------------- */

/* 上拉输入，按下为低电平。
 * PB1  启动 / 停止（停止后回原点）
 * PB11 暂停 / 继续
 * PB3~PB7 由 Button.c 做角度微调，和这两个不冲突 */
#define ENABLE_KEYS       1
#define KEY_START_PIN     GPIO_Pin_1
#define KEY_PAUSE_PIN     GPIO_Pin_11

/* 超过该时间没收到四角数据就停下，防止光斑扫出靶纸 */
#define CAM_TIMEOUT_MS    800u

#endif
