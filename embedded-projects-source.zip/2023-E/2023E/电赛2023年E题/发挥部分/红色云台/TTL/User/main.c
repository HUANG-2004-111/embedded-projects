/*
 * 红色云台控制程序
 *
 * 双轴云台挂红色激光笔，OpenMV 识别 A4 靶纸四周的黑色电工胶带，
 * 把四个角点坐标通过串口发过来。程序按 0->1->2->3->0 的顺序依次
 * 对准四个角，光斑就沿胶带走完一圈；中途可以暂停，停下后立即制动
 * 并保持锁力。
 *
 * USART1 PA9/PA10  总线舵机
 * USART2 PA2/PA3   OpenMV
 * PB8/PB9          OLED
 * PB1 / PB11       启动-停止 / 暂停
 * PB3~PB7          角度微调（Button.c）
 */
#include "stm32f10x.h"
#include "usart.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "Button.h"
#include "app_config.h"
#include <stdio.h>

#define RX_BUFFER_SIZE 80

/* 串口帧，23 字节
 *
 *   3C | WH WL | HH HL | 2C | x0H x0L y0H y0L | ... | x3H x3L y3H y3L | 5B
 *
 * W/H 是靶纸外接矩形的像素宽高，用来换算像素/厘米的比例。
 */
uint16_t xx[8];
uint16_t yy[8];
char RxBuffer[RX_BUFFER_SIZE];
volatile uint8_t RxIndex = 0;

typedef enum
{
    STATE_WAIT_HEADER,
    STATE_RECEIVE_WIDTH,
    STATE_RECEIVE_HEIGHT,
    STATE_WAIT_SECOND_HEADER,
    STATE_RECEIVE_DATA,
    STATE_WAIT_TAIL
} ReceiveState;

ReceiveState state = STATE_WAIT_HEADER;
uint8_t data_received = 0;
uint16_t CALIB_OBJECT_WIDTH_PIXEL;
uint16_t CALIB_OBJECT_HEIGHT_PIXEL;

#define SCREEN_WIDTH  320
#define SCREEN_HEIGHT 240
#define SCREEN_CENTER_X (SCREEN_WIDTH / 2)
#define SCREEN_CENTER_Y (SCREEN_HEIGHT / 2)

#define HORIZONTAL_MIN_ANGLE -90
#define HORIZONTAL_MAX_ANGLE 90
#define VERTICAL_MIN_ANGLE -45
#define VERTICAL_MAX_ANGLE 45

Usart_DataTypeDef *servo_usart = &usart1;
Usart_DataTypeDef *logging_usart = &usart2;

int fputc(int ch, FILE *f)
{
    while ((logging_usart->pUSARTx->SR & 0x40) == 0)
    {
    }
    USART_SendData(logging_usart->pUSARTx, (uint8_t)ch);
    return ch;
}

/* 逐字节解析：帧头 -> 宽高 -> 第二个帧头 -> 4 个角点 -> 帧尾 */
void USART2_IRQHandler(void)
{
    uint8_t received;

    if (USART_GetITStatus(USART2, USART_IT_RXNE) == RESET)
    {
        return;
    }

    received = USART_ReceiveData(USART2);

    switch (state)
    {
        case STATE_WAIT_HEADER:
            if (received == 0x3C)
            {
                state = STATE_RECEIVE_WIDTH;
                RxIndex = 0;
            }
            break;

        case STATE_RECEIVE_WIDTH:
            if (RxIndex == 0)
            {
                CALIB_OBJECT_WIDTH_PIXEL = received;
            }
            else if (RxIndex == 1)
            {
                CALIB_OBJECT_WIDTH_PIXEL |= received;
                state = STATE_RECEIVE_HEIGHT;
            }
            RxIndex++;
            break;

        case STATE_RECEIVE_HEIGHT:
            if (RxIndex == 2)
            {
                CALIB_OBJECT_HEIGHT_PIXEL = received;
            }
            else if (RxIndex == 3)
            {
                CALIB_OBJECT_HEIGHT_PIXEL |= received;
                state = STATE_WAIT_SECOND_HEADER;
                RxIndex = 0;
            }
            RxIndex++;
            break;

        case STATE_WAIT_SECOND_HEADER:
            if (received == 0x2C)
            {
                state = STATE_RECEIVE_DATA;
                RxIndex = 0;
            }
            break;

        case STATE_RECEIVE_DATA:
            if (received == 0x5B)
            {
                state = STATE_WAIT_TAIL;
                data_received = 1;
            }
            else if (RxIndex < RX_BUFFER_SIZE - 1)
            {
                RxBuffer[RxIndex++] = received;
            }
            break;

        default:                        /* STATE_WAIT_TAIL */
            state = STATE_WAIT_HEADER;
            break;
    }
}

/* 解析出一组完整四角坐标返回 1 */
uint8_t Process_Received_Data(void)
{
    uint8_t ok = 0;
    uint8_t i;

    if (!data_received)
    {
        return 0;
    }

    if (RxIndex >= 16)
    {
        for (i = 0; i < 4; i++)
        {
            int base = i * 4;
            xx[i] = (RxBuffer[base] << 8) | RxBuffer[base + 1];
            yy[i] = (RxBuffer[base + 2] << 8) | RxBuffer[base + 3];
        }
        ok = 1;
    }

    data_received = 0;
    RxIndex = 0;
    state = STATE_WAIT_HEADER;
    return ok;
}

#define CALIB_OBJECT_WIDTH_CM    23.0f
#define CALIB_OBJECT_HEIGHT_CM   31.7f
#define SCALE_X (CALIB_OBJECT_WIDTH_PIXEL / CALIB_OBJECT_WIDTH_CM)
#define SCALE_Y (CALIB_OBJECT_HEIGHT_PIXEL / CALIB_OBJECT_HEIGHT_CM)

/* 相机和激光笔的位置偏差，换算成像素 */
#define CAMERA_LASER_OFFSET_X (0.2f * SCALE_X)
#define CAMERA_LASER_OFFSET_Y (5.0f * SCALE_Y)

void ConvertCoordinatesToAngles(int16_t x, int16_t y, float *h_angle, float *v_angle)
{
    int16_t adjusted_x = x - CAMERA_LASER_OFFSET_X;
    int16_t adjusted_y = y - CAMERA_LASER_OFFSET_Y;
    int16_t dx = adjusted_x - SCREEN_CENTER_X;
    int16_t dy = adjusted_y - SCREEN_CENTER_Y;

    *h_angle = (float)dx / SCREEN_CENTER_X * HORIZONTAL_MAX_ANGLE;
    *v_angle = (float)dy / SCREEN_CENTER_Y * VERTICAL_MAX_ANGLE;

    if (*h_angle < HORIZONTAL_MIN_ANGLE)
    {
        *h_angle = HORIZONTAL_MIN_ANGLE;
    }
    if (*h_angle > HORIZONTAL_MAX_ANGLE)
    {
        *h_angle = HORIZONTAL_MAX_ANGLE;
    }
    if (*v_angle < VERTICAL_MIN_ANGLE)
    {
        *v_angle = VERTICAL_MIN_ANGLE;
    }
    if (*v_angle > VERTICAL_MAX_ANGLE)
    {
        *v_angle = VERTICAL_MAX_ANGLE;
    }
}

/* ------------------------------------------------------------------ */
/* 复位、暂停、按键                                                   */
/* ------------------------------------------------------------------ */

static uint8_t run_flag;            /* 1 = 正在巡边 */
static uint8_t paused;              /* 1 = 暂停中 */
static uint8_t point_index;         /* 0..4，第 5 步回到 0 号角，正好一圈 */
static uint8_t have_frame;
static uint32_t now_ms;             /* 10ms 一跳的软时基 */
static uint32_t last_frame_ms;

static void servo_stop(void)
{
    /* 指令 24：控制模式停止，mode=1 停止后保持锁力 */
    FSUS_StopOnControlMode(servo_usart, PAN_SERVO_ID, 1, 0);
    FSUS_StopOnControlMode(servo_usart, TILT_SERVO_ID, 1, 0);
}

static void go_home(void)
{
    float pan  = HOME_PAN_DEG + servo0_angle;
    float tilt = HOME_TILT_DEG + servo1_angle;

    if (pan < PAN_MIN_DEG)
    {
        pan = PAN_MIN_DEG;
    }
    if (pan > PAN_MAX_DEG)
    {
        pan = PAN_MAX_DEG;
    }
    if (tilt < TILT_MIN_DEG)
    {
        tilt = TILT_MIN_DEG;
    }
    if (tilt > TILT_MAX_DEG)
    {
        tilt = TILT_MAX_DEG;
    }

    FSUS_SetServoAngle(servo_usart, PAN_SERVO_ID,  pan,  HOME_MOVE_MS, 0);
    FSUS_SetServoAngle(servo_usart, TILT_SERVO_ID, tilt, HOME_MOVE_MS, 0);

    point_index = 0;
    run_flag = 0;
    paused = 0;
}

/* 走到第 i 个角 */
static void move_to_point(uint8_t i)
{
    float h_angle;
    float v_angle;
    float base_servo0;
    float base_servo1;
    float final_servo0;
    float final_servo1;

    ConvertCoordinatesToAngles(xx[i], yy[i], &h_angle, &v_angle);

    base_servo0 = (h_angle * 7) / 12 - 5.65f;
    base_servo1 = -(v_angle * 0.7f - 10.2f);
    final_servo0 = base_servo0 + servo0_angle;
    final_servo1 = base_servo1 + servo1_angle;

    if (final_servo0 < PAN_MIN_DEG)
    {
        final_servo0 = PAN_MIN_DEG;
    }
    if (final_servo0 > PAN_MAX_DEG)
    {
        final_servo0 = PAN_MAX_DEG;
    }
    if (final_servo1 < TILT_MIN_DEG)
    {
        final_servo1 = TILT_MIN_DEG;
    }
    if (final_servo1 > TILT_MAX_DEG)
    {
        final_servo1 = TILT_MAX_DEG;
    }

    FSUS_SetServoAngle(servo_usart, PAN_SERVO_ID,  final_servo0, TRACE_MOVE_MS, 0);
    FSUS_SetServoAngle(servo_usart, TILT_SERVO_ID, final_servo1, TRACE_MOVE_MS, 0);
}

static void oled_fix1(uint8_t line, uint8_t col, float v)
{
    char buf[16];
    int32_t t = (int32_t)(v * 10.0f + (v >= 0.0f ? 0.5f : -0.5f));
    int32_t a = (t < 0) ? -t : t;

    sprintf(buf, "%s%d.%d", (t < 0) ? "-" : "+", (int)(a / 10), (int)(a % 10));
    OLED_ShowString(line, col, buf);
}

static void oled_status(void)
{
    if (paused)
    {
        OLED_ShowString(1, 1, "PAUSED    ");
    }
    else if (run_flag)
    {
        OLED_ShowString(1, 1, "TRACE     ");
    }
    else
    {
        OLED_ShowString(1, 1, "READY     ");
    }

    OLED_ShowString(2, 1, "POINT ");
    OLED_ShowNum(2, 7, (uint32_t)(run_flag ? (point_index & 0x03) + 1 : 0), 1);
    OLED_ShowString(2, 9, "/4");

    OLED_ShowString(3, 1, "PAN ");
    oled_fix1(3, 5, HOME_PAN_DEG + servo0_angle);

    OLED_ShowString(4, 1, have_frame ? "PB1 GO PB11 PAU" : "NO CAMERA");
}

/* 返回 bit0 = PB1 按下沿，bit1 = PB11 按下沿 */
static uint8_t key_scan(void)
{
    static uint8_t raw_s, raw_p, st_s, st_p, cnt_s, cnt_p;
    uint8_t out = 0;
    uint8_t rs;
    uint8_t rp;

    rs = (GPIO_ReadInputDataBit(GPIOB, KEY_START_PIN) == 0) ? 1 : 0;
    rp = (GPIO_ReadInputDataBit(GPIOB, KEY_PAUSE_PIN) == 0) ? 1 : 0;

    if (rs != raw_s)
    {
        raw_s = rs;
        cnt_s = 0;
    }
    else if (rs != st_s)
    {
        if (++cnt_s >= 2)
        {
            st_s = rs;
            if (rs)
            {
                out |= 0x01;
            }
        }
    }
    else
    {
        cnt_s = 0;
    }

    if (rp != raw_p)
    {
        raw_p = rp;
        cnt_p = 0;
    }
    else if (rp != st_p)
    {
        if (++cnt_p >= 2)
        {
            st_p = rp;
            if (rp)
            {
                out |= 0x02;
            }
        }
    }
    else
    {
        cnt_p = 0;
    }

    return out;
}

/* 停留 ms，期间一直扫按键；返回 0 表示被打断 */
static uint8_t dwell_with_keys(uint16_t ms)
{
    uint16_t t;
    uint8_t k;

    for (t = 0; t < ms; t += 10)
    {
        k = key_scan();

        if (k & 0x02)
        {
            paused = 1;
            servo_stop();
            OLED_Clear();
            oled_status();
            return 0;
        }

        if (k & 0x01)
        {
            run_flag = 0;
            paused = 0;
            go_home();
            OLED_Clear();
            oled_status();
            return 0;
        }

        SysTick_DelayMs(10);
    }

    return 1;
}

/* ------------------------------------------------------------------ */

int main(void)
{
    GPIO_InitTypeDef gpio;
    uint8_t keys;

    SysTick_Init();
    Usart_Init();
    OLED_Init();
    Button_Init();

#if ENABLE_KEYS
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    gpio.GPIO_Pin   = KEY_START_PIN | KEY_PAUSE_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_IPU;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio);
#endif

    go_home();
    OLED_Clear();
    oled_status();

    while (1)
    {
        now_ms += 10;

        if (Process_Received_Data())
        {
            have_frame = 1;
            last_frame_ms = now_ms;
        }

        /* 摄像头断线：立即停，避免光斑乱跑 */
        if (run_flag && have_frame && (now_ms - last_frame_ms) > CAM_TIMEOUT_MS)
        {
            servo_stop();
            run_flag = 0;
            paused = 0;
            OLED_Clear();
            OLED_ShowString(1, 1, "CAM LOST");
            go_home();
        }

        keys = key_scan();

        if (keys & 0x01)
        {
            if (run_flag || paused)
            {
                servo_stop();
                go_home();
                OLED_Clear();
                oled_status();
            }
            else if (!have_frame)
            {
                OLED_Clear();
                OLED_ShowString(1, 1, "NO CAMERA");
                OLED_ShowString(2, 1, "CHECK OPENMV");
            }
            else
            {
                run_flag = 1;
                paused = 0;
                point_index = 0;
                OLED_Clear();
                oled_status();
            }
        }

        if (keys & 0x02)
        {
            if (paused)
            {
                paused = 0;
                move_to_point(point_index & 0x03);
                OLED_Clear();
                oled_status();
            }
            else if (run_flag)
            {
                paused = 1;
                servo_stop();
                OLED_Clear();
                oled_status();
            }
        }

        if (run_flag && !paused)
        {
            move_to_point(point_index & 0x03);
            oled_status();

            if (dwell_with_keys(TRACE_DWELL_MS))
            {
                point_index++;
                /* 0->1->2->3->0 走完一圈，停在 0 号角 */
                if (point_index > 4)
                {
                    run_flag = 0;
                    point_index = 0;
                    OLED_Clear();
                    OLED_ShowString(1, 1, "DONE 1 LAP");
                    OLED_ShowString(2, 1, "PB1 AGAIN");
                }
            }
        }

        SysTick_DelayMs(10);
    }
}
