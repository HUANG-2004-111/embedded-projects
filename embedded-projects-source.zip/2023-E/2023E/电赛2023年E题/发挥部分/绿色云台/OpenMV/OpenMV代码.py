# 绿色激光光斑跟踪 - OpenMV
#
# 同时检测红色和绿色激光光斑，把两者的像素坐标按 13 字节定长帧
# 发给 STM32（UART3，P4=TX，P5=RX，115200）。
#
# 帧格式：
#   A5 5A FLAGS XRH XRL YRH YRL XGH XGL YGH YGL SUM 5B
#   FLAGS  bit0 红点有效，bit1 绿点有效，bit2 两点重合
#   SUM    FLAGS 到 YGL 共 9 字节求和取低 8 位
#   坐标无效时填 0

import sensor
import time
from pyb import UART

# 串口
UART_ID = 3
UART_BAUD = 115200

# 图像
VFLIP = True
HMIRROR = True
EXPOSURE_US = 6000
GAIN_DB = 0.0
BRIGHTNESS = 0
CONTRAST = 0
FRAME_PERIOD_MS = 10

# 颜色阈值（LAB）。红色激光 A 分量很大，绿色激光 A 分量很小，
# 白色屏幕 A 约为 0，两边都会被排除。
RED_THRESHOLD = [(15, 100, 25, 127, -20, 127)]
GREEN_THRESHOLD = [(15, 100, -128, -20, -70, 90)]

# 光斑过滤参数
PIXELS_MIN = 4
PIXELS_MAX = 600
DENSITY_MIN = 0.25
ASPECT_MAX = 4.0
MERGE_DIST_PX = 5

DRAW_DEBUG = True

uart = UART(UART_ID, UART_BAUD, bits=8, parity=None, stop=1,
            timeout=50, timeout_char=2)


def find_spot(img, thresholds, roi):
    """返回 (x, y, rect)，取评分最高的光斑；没有返回 None。"""
    best = None
    best_score = 0

    for b in img.find_blobs(thresholds, roi=roi,
                            x_stride=2, y_stride=2,
                            pixels_threshold=PIXELS_MIN,
                            area_threshold=PIXELS_MIN,
                            merge=False):
        w = b.w()
        h = b.h()
        area = w * h
        if w <= 0 or h <= 0 or area <= 0:
            continue

        pixels = b.pixels()
        if pixels < PIXELS_MIN or pixels > PIXELS_MAX:
            continue

        density = pixels / float(area)
        if density < DENSITY_MIN:
            continue

        if max(w, h) > ASPECT_MAX * min(w, h):
            continue

        score = pixels * density
        if score > best_score:
            best_score = score
            best = (b.cx(), b.cy(), b.rect())

    return best


def put_u16(buf, index, value):
    value = int(value) & 0xFFFF
    buf[index] = (value >> 8) & 0xFF
    buf[index + 1] = value & 0xFF


def send_frame(flags, red, green):
    pkt = bytearray(13)

    pkt[0] = 0xA5
    pkt[1] = 0x5A
    pkt[2] = flags & 0xFF

    put_u16(pkt, 3, red[0] if red else 0)
    put_u16(pkt, 5, red[1] if red else 0)
    put_u16(pkt, 7, green[0] if green else 0)
    put_u16(pkt, 9, green[1] if green else 0)

    pkt[11] = sum(pkt[2:11]) & 0xFF
    pkt[12] = 0x5B

    uart.write(pkt)


def main():
    sensor.reset()
    sensor.set_pixformat(sensor.RGB565)
    sensor.set_framesize(sensor.QVGA)
    sensor.set_vflip(VFLIP)
    sensor.set_hmirror(HMIRROR)
    sensor.set_brightness(BRIGHTNESS)
    sensor.set_contrast(CONTRAST)
    sensor.skip_frames(time=1000)
    sensor.set_auto_gain(False, gain_db=GAIN_DB)
    sensor.set_auto_whitebal(False)
    sensor.set_auto_exposure(False, exposure_us=EXPOSURE_US)
    sensor.skip_frames(time=300)

    clock = time.clock()
    roi = (0, 0, 320, 240)

    while True:
        clock.tick()
        img = sensor.snapshot()

        red = find_spot(img, RED_THRESHOLD, roi)
        green = find_spot(img, GREEN_THRESHOLD, roi)

        flags = 0
        if red:
            flags |= 0x01
        if green:
            flags |= 0x02

        if red and green:
            dx = red[0] - green[0]
            dy = red[1] - green[1]
            if dx * dx + dy * dy <= MERGE_DIST_PX * MERGE_DIST_PX:
                # 两点几乎重合，取中点，避免坐标来回跳
                flags |= 0x04
                cx = (red[0] + green[0]) // 2
                cy = (red[1] + green[1]) // 2
                red = (cx, cy, red[2])
                green = (cx, cy, green[2])

        send_frame(flags, red, green)

        if DRAW_DEBUG:
            if red:
                img.draw_rectangle(red[2], color=(255, 0, 0))
                img.draw_cross(red[0], red[1], color=(255, 0, 0), size=5)
            if green:
                img.draw_rectangle(green[2], color=(0, 255, 0))
                img.draw_cross(green[0], green[1], color=(0, 255, 0), size=5)

            img.draw_string(2, 2, "R%d G%d %dfps" % (
                flags & 1, (flags >> 1) & 1, int(clock.fps())),
                color=(255, 255, 0))

        time.sleep_ms(FRAME_PERIOD_MS)


main()
