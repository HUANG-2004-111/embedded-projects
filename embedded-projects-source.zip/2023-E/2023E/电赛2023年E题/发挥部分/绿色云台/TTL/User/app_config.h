#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/*
 * 绿色云台参数配置
 *
 * 接线、行程、闭环增益、判定阈值都集中在这里，调参不用动 main.c。
 */

/* ---------------- 舵机 ---------------- */

#define PAN_SERVO_ID      0u
#define TILT_SERVO_ID     1u

/* 机械行程，按实际云台改，用来做软件限幅保护 */
#define PAN_MIN_DEG       (-90.0f)
#define PAN_MAX_DEG       ( 90.0f)
#define TILT_MIN_DEG      (-30.0f)
#define TILT_MAX_DEG      ( 30.0f)

/* 上电/重新启动时先转到这个角度，大致对准屏幕中心 */
#define START_PAN_DEG     0.0f
#define START_TILT_DEG    0.0f
#define START_MOVE_MS     500u

/* ---------------- 闭环参数 ---------------- */

/*
 * 比例增益，单位：度/像素。
 * 相机 1m 左右看 0.5m 屏，QVGA 下 1 像素约 1.5~2mm，约 0.1 度。
 * 舵机和相机有 60~80ms 滞后，增益取太大会来回摆，0.03~0.04 比较稳。
 */
#define KP_PAN            0.035f
#define KP_TILT           0.035f

/* 修正方向：绿点越追越远时，把对应项取反 */
#define DIR_PAN           (-1.0f)
#define DIR_TILT          ( 1.0f)

/* 单个周期最大修正角度，防止大偏差时猛甩 */
#define MAX_STEP_DEG      5.0f

/* 偏差小于该像素数就不再动作，避免原地抖 */
#define DEADBAND_PX       3.0f

/* 控制周期(ms)，比相机帧间隔略大，保证每帧都能用上 */
#define CTRL_PERIOD_MS    40u

/* ---------------- 判定 ---------------- */

/*
 * 像素与实际尺寸的换算，现场量一下：屏幕上 100mm 对应多少像素。
 * 例：100mm 对应 52 像素 -> 1.92
 */
#define MM_PER_PX         1.92f
#define SUCCESS_MM        30.0f
#define SUCCESS_PX        (SUCCESS_MM / MM_PER_PX)
#define OK_FRAMES         3u

/* 超过该时间没收到新帧就认为跟丢，撤销提示并保持当前角度 */
#define LOST_MS           300u

/* ---------------- 按键与声光 ---------------- */

/* 上拉输入，按下为低电平 */
#define ENABLE_KEYS       1
#define KEY_START_PIN     GPIO_Pin_1
#define KEY_PAUSE_PIN     GPIO_Pin_11

/* 有源蜂鸣器接 PB12，高电平响；PC13 板载 LED，低电平亮 */
#define ENABLE_PIEZO      1
#define PIEZO_PORT        GPIOB
#define PIEZO_PIN         GPIO_Pin_12
#define PIEZO_ACTIVE_HIGH 1
#define ENABLE_LED        1
#define LED_PORT          GPIOC
#define LED_PIN           GPIO_Pin_13

#endif
