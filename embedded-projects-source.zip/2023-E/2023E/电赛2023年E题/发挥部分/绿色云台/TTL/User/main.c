/*
 * 绿色云台控制程序
 *
 * 双轴云台挂绿色激光笔，OpenMV 同时检测红色和绿色两个光斑，
 * 把坐标通过串口发过来。控制量取两点的像素偏差，按比例逐周期
 * 修正两个舵机角度，让绿点向红点靠拢，重合后给出声光提示。
 *
 * 相机和云台一起转动，绿点在画面里的位置随舵机变化，所以只要确认
 * 修正方向就行，不需要标定像素和实际角度的对应关系。
 *
 * USART1 PA9/PA10  总线舵机
 * USART2 PA2/PA3   OpenMV
 * PB8/PB9          OLED
 * PB1 / PB11       启动 / 暂停
 * PB12 / PC13      蜂鸣器 / LED
 */
#include "stm32f10x.h"
#include "usart.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "app_config.h"
#include <math.h>
#include <stdio.h>

/*
 * 相机帧，13 字节
 *
 *   A5 5A | flags | xrH xrL | yrH yrL | xgH xgL | ygH ygL | sum | 5B
 *
 *   flags  bit0 红点有效，bit1 绿点有效，bit2 两点重合
 *   sum    flags 到 ygL 共 9 字节求和取低 8 位
 */
#define FRAME_BYTES   11u         /* A5 5A 之后的字节数，含校验和帧尾 */
#define FLAG_RED      0x01u
#define FLAG_GREEN    0x02u
#define FLAG_MERGED   0x04u

typedef struct
{
    uint8_t flags;
    int16_t xr;
    int16_t yr;
    int16_t xg;
    int16_t yg;
} SpotFrame;

static volatile SpotFrame g_frame;
static volatile uint8_t   g_frame_ready;
static volatile uint8_t   g_rx_state;
static volatile uint8_t   g_rx_idx;
static volatile uint8_t   g_rx_buf[FRAME_BYTES];

Usart_DataTypeDef *servo_usart = &usart1;

/* 串口接收状态机：找帧头 -> 收 11 字节 -> 校验和、帧尾 */
void USART2_IRQHandler(void)
{
    uint8_t b;
    uint8_t i;
    uint8_t sum;

    if ((USART2->SR & USART_SR_RXNE) == 0)
    {
        return;
    }
    b = (uint8_t)USART2->DR;                /* 读 DR 同时清 RXNE */

    if (g_rx_state == 0)
    {
        if (b == 0xA5)
        {
            g_rx_state = 1;
        }
        return;
    }

    if (g_rx_state == 1)
    {
        if (b == 0x5A)
        {
            g_rx_state = 2;
            g_rx_idx = 0;
        }
        else if (b != 0xA5)
        {
            g_rx_state = 0;
        }
        return;
    }

    g_rx_buf[g_rx_idx++] = b;
    if (g_rx_idx < FRAME_BYTES)
    {
        return;
    }
    g_rx_state = 0;

    if (g_rx_buf[FRAME_BYTES - 1] != 0x5B)
    {
        return;
    }

    sum = 0;
    for (i = 0; i < 9u; i++)
    {
        sum = (uint8_t)(sum + g_rx_buf[i]);
    }
    if (sum != g_rx_buf[9])
    {
        return;
    }

    g_frame.flags = g_rx_buf[0];
    g_frame.xr = (int16_t)(((uint16_t)g_rx_buf[1] << 8) | g_rx_buf[2]);
    g_frame.yr = (int16_t)(((uint16_t)g_rx_buf[3] << 8) | g_rx_buf[4]);
    g_frame.xg = (int16_t)(((uint16_t)g_rx_buf[5] << 8) | g_rx_buf[6]);
    g_frame.yg = (int16_t)(((uint16_t)g_rx_buf[7] << 8) | g_rx_buf[8]);
    g_frame_ready = 1;
}

/* ------------------------------------------------------------------ */
/* 舵机                                                               */
/* ------------------------------------------------------------------ */

static float g_pan  = START_PAN_DEG;
static float g_tilt = START_TILT_DEG;

static float clampf(float v, float lo, float hi)
{
    if (v < lo)
    {
        return lo;
    }
    if (v > hi)
    {
        return hi;
    }
    return v;
}

static void servo_stop(void)
{
    /* 指令 24：控制模式停止，mode=1 停止后保持锁力 */
    FSUS_StopOnControlMode(servo_usart, PAN_SERVO_ID, 1, 0);
    FSUS_StopOnControlMode(servo_usart, TILT_SERVO_ID, 1, 0);
}

static void servo_send(float pan, float tilt, uint16_t ms)
{
    pan  = clampf(pan,  PAN_MIN_DEG,  PAN_MAX_DEG);
    tilt = clampf(tilt, TILT_MIN_DEG, TILT_MAX_DEG);
    FSUS_SetServoAngle(servo_usart, PAN_SERVO_ID,  pan,  ms, 0);
    FSUS_SetServoAngle(servo_usart, TILT_SERVO_ID, tilt, ms, 0);
}

/* ------------------------------------------------------------------ */
/* 运行状态                                                           */
/* ------------------------------------------------------------------ */

enum
{
    MODE_IDLE = 0,
    MODE_RUN,
    MODE_PAUSE
};

static uint8_t  g_mode;
static uint8_t  g_ok_count;
static uint32_t g_now_ms;           /* 1ms 软时基，主循环每圈加一 */
static uint32_t g_last_rx_ms;
static uint32_t g_last_ctrl_ms;
static uint32_t g_run_ms;
static uint32_t g_acq_ms;           /* 启动到跟上的时间，0 未跟上，0xFFFFFFFF 超时 */
static float    g_dist_px;
static uint8_t  g_dist_valid;

/* ------------------------------------------------------------------ */
/* 按键与声光                                                         */
/* ------------------------------------------------------------------ */

static void outputs_init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);

    gpio.GPIO_Mode  = GPIO_Mode_Out_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;

#if ENABLE_PIEZO
    gpio.GPIO_Pin = PIEZO_PIN;
    GPIO_Init(PIEZO_PORT, &gpio);
    GPIO_ResetBits(PIEZO_PORT, PIEZO_PIN);
#endif

#if ENABLE_LED
    gpio.GPIO_Pin = LED_PIN;
    GPIO_Init(LED_PORT, &gpio);
    GPIO_SetBits(LED_PORT, LED_PIN);            /* 低电平亮，先关掉 */
#endif

#if ENABLE_KEYS
    gpio.GPIO_Pin  = KEY_START_PIN | KEY_PAUSE_PIN;
    gpio.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &gpio);
#endif
}

static void outputs_set(uint8_t on)
{
#if ENABLE_PIEZO
#if PIEZO_ACTIVE_HIGH
    if (on)
    {
        GPIO_SetBits(PIEZO_PORT, PIEZO_PIN);
    }
    else
    {
        GPIO_ResetBits(PIEZO_PORT, PIEZO_PIN);
    }
#else
    if (on)
    {
        GPIO_ResetBits(PIEZO_PORT, PIEZO_PIN);
    }
    else
    {
        GPIO_SetBits(PIEZO_PORT, PIEZO_PIN);
    }
#endif
#endif

#if ENABLE_LED
    if (on)
    {
        GPIO_ResetBits(LED_PORT, LED_PIN);
    }
    else
    {
        GPIO_SetBits(LED_PORT, LED_PIN);
    }
#endif
}

/* 返回 bit0 = PB1 按下沿，bit1 = PB11 按下沿 */
static uint8_t key_scan(void)
{
    static uint8_t raw_s, raw_p, st_s, st_p, cnt_s, cnt_p;
    uint8_t out = 0;
    uint8_t rs;
    uint8_t rp;

#if ENABLE_KEYS
    rs = (GPIO_ReadInputDataBit(GPIOB, KEY_START_PIN) == 0) ? 1 : 0;
    rp = (GPIO_ReadInputDataBit(GPIOB, KEY_PAUSE_PIN) == 0) ? 1 : 0;
#else
    rs = 0;
    rp = 0;
#endif

    if (rs != raw_s)
    {
        raw_s = rs;
        cnt_s = 0;
    }
    else if (rs != st_s)
    {
        if (++cnt_s >= 2)
        {
            st_s = rs;
            if (rs)
            {
                out |= 0x01;
            }
        }
    }
    else
    {
        cnt_s = 0;
    }

    if (rp != raw_p)
    {
        raw_p = rp;
        cnt_p = 0;
    }
    else if (rp != st_p)
    {
        if (++cnt_p >= 2)
        {
            st_p = rp;
            if (rp)
            {
                out |= 0x02;
            }
        }
    }
    else
    {
        cnt_p = 0;
    }

    return out;
}

/* ------------------------------------------------------------------ */
/* 显示                                                               */
/* ------------------------------------------------------------------ */

static void oled_fix1(uint8_t line, uint8_t col, float v)
{
    char buf[16];
    int32_t t = (int32_t)(v * 10.0f + (v >= 0.0f ? 0.5f : -0.5f));
    int32_t a = (t < 0) ? -t : t;

    sprintf(buf, "%s%d.%d", (t < 0) ? "-" : "+", (int)(a / 10), (int)(a % 10));
    OLED_ShowString(line, col, buf);
}

static void oled_status(uint8_t ok)
{
    if (g_mode == MODE_IDLE)
    {
        OLED_ShowString(1, 1, "IDLE       ");
    }
    else if (g_mode == MODE_PAUSE)
    {
        OLED_ShowString(1, 1, "PAUSED     ");
    }
    else
    {
        OLED_ShowString(1, 1, "TRACKING   ");
    }

    OLED_ShowString(1, 12, ok ? "OK" : "  ");

    OLED_ShowString(2, 1, "DIST");
    if (g_dist_valid)
    {
        OLED_ShowNum(2, 6, (uint32_t)(g_dist_px * MM_PER_PX), 3);
    }
    else
    {
        OLED_ShowString(2, 6, "---");
    }
    OLED_ShowString(2, 10, "mm  ");

    OLED_ShowString(3, 1, "PAN ");
    oled_fix1(3, 5, g_pan);
    OLED_ShowString(4, 1, "TIL ");
    oled_fix1(4, 5, g_tilt);
}

/* ------------------------------------------------------------------ */
/* 跟踪                                                               */
/* ------------------------------------------------------------------ */

static void track_step(const SpotFrame *f)
{
    float ex;
    float ey;
    float dist;
    float step;

    if (f->flags & FLAG_MERGED)
    {
        g_dist_px = 0.0f;
        g_dist_valid = 1;
        g_ok_count = 200u;
        return;
    }

    if ((f->flags & (FLAG_RED | FLAG_GREEN)) != (FLAG_RED | FLAG_GREEN))
    {
        /* 只看到一个点，量不了距离，保持当前角度 */
        g_dist_valid = 0;
        return;
    }

    ex = (float)f->xg - (float)f->xr;
    ey = (float)f->yg - (float)f->yr;
    dist = sqrtf(ex * ex + ey * ey);
    g_dist_px = dist;
    g_dist_valid = 1;

    if (dist <= SUCCESS_PX)
    {
        if (g_ok_count < 200u)
        {
            g_ok_count++;
        }
    }
    else
    {
        g_ok_count = 0;
    }

    if (dist <= DEADBAND_PX)
    {
        return;
    }

    step = KP_PAN * ex * DIR_PAN;
    g_pan += clampf(step, -MAX_STEP_DEG, MAX_STEP_DEG);

    step = KP_TILT * ey * DIR_TILT;
    g_tilt += clampf(step, -MAX_STEP_DEG, MAX_STEP_DEG);

    g_pan  = clampf(g_pan,  PAN_MIN_DEG,  PAN_MAX_DEG);
    g_tilt = clampf(g_tilt, TILT_MIN_DEG, TILT_MAX_DEG);
    servo_send(g_pan, g_tilt, CTRL_PERIOD_MS);
}

/* ------------------------------------------------------------------ */

int main(void)
{
    uint8_t  ok = 0;
    uint8_t  keys;
    uint32_t last_disp = 0;
    SpotFrame f;

    SysTick_Init();
    Usart_Init();
    OLED_Init();
    outputs_init();

    g_pan  = START_PAN_DEG;
    g_tilt = START_TILT_DEG;
    servo_send(g_pan, g_tilt, START_MOVE_MS);
    SysTick_DelayMs(100);

    OLED_Clear();
    oled_status(0);

    while (1)
    {
        g_now_ms++;

        /* 收到一帧就更新一次误差 */
        if (g_frame_ready)
        {
            g_frame_ready = 0;
            f.flags = g_frame.flags;
            f.xr = g_frame.xr;
            f.yr = g_frame.yr;
            f.xg = g_frame.xg;
            f.yg = g_frame.yg;
            g_last_rx_ms = g_now_ms;

            if (g_mode == MODE_RUN &&
                (g_now_ms - g_last_ctrl_ms) >= CTRL_PERIOD_MS)
            {
                g_last_ctrl_ms = g_now_ms;
                track_step(&f);
            }
        }

        if (g_mode == MODE_RUN && (g_now_ms - g_last_rx_ms) > LOST_MS)
        {
            g_dist_valid = 0;
            g_ok_count = 0;
        }

        ok = (g_mode == MODE_RUN && g_ok_count >= OK_FRAMES) ? 1 : 0;
        outputs_set(ok);

        if (ok && g_acq_ms == 0 && g_run_ms > 0)
        {
            g_acq_ms = g_run_ms;
        }

        keys = key_scan();

        if (keys & 0x01)
        {
            if (g_mode == MODE_IDLE)
            {
                g_pan  = START_PAN_DEG;
                g_tilt = START_TILT_DEG;
                servo_send(g_pan, g_tilt, START_MOVE_MS);
                g_mode = MODE_RUN;
                g_ok_count = 0;
                g_run_ms = 0;
                g_acq_ms = 0;
                g_last_rx_ms = g_now_ms;
                g_last_ctrl_ms = 0;
                g_dist_valid = 0;
            }
            else
            {
                g_mode = MODE_IDLE;
                servo_stop();
                g_ok_count = 0;
                outputs_set(0);
            }
            OLED_Clear();
            last_disp = 0;
        }

        if ((keys & 0x02) && g_mode != MODE_IDLE)
        {
            if (g_mode == MODE_PAUSE)
            {
                g_mode = MODE_RUN;
                g_last_ctrl_ms = 0;             /* 立即用最新一帧修正 */
                g_last_rx_ms = g_now_ms;
            }
            else
            {
                g_mode = MODE_PAUSE;
                servo_stop();
                outputs_set(0);
            }
            OLED_Clear();
            last_disp = 0;
        }

        if (g_mode == MODE_RUN)
        {
            g_run_ms++;
            if (g_acq_ms == 0 && g_run_ms > 2000u)
            {
                g_acq_ms = 0xFFFFFFFFu;
            }
        }

        if (++last_disp >= 100u)
        {
            last_disp = 0;
            oled_status(ok);
            if (g_mode == MODE_RUN && g_acq_ms != 0)
            {
                OLED_ShowString(2, 14, (g_acq_ms == 0xFFFFFFFFu) ? "SL" : "OK");
            }
        }

        SysTick_DelayMs(1);
    }
}
