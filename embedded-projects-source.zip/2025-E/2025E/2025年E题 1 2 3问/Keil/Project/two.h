#ifndef _TWO_H
#define _TWO_H

#include "stm32f10x.h"                  // Device header
#include "sys_tick.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "key.h"
#include "fashion_star_uart_servo.h"

void two (void);



#endif