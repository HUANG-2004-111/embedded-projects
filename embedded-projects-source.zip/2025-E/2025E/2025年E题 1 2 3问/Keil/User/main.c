#include "stm32f10x.h"
#include "usart.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "Button.h"  			// 引用Button头文件，获取全局变量声明
#include "key.h"
#include "two.h"
#define   RX_BUFFER_SIZE 100

// 定义接收缓冲区大小
uint8_t  isTimeUp = 0,flag1=0; 		   // 关键：添加这行声明
uint32_t system_running_time = 0;  		// 系统运行时间(ms)
uint16_t xx,yy,xs,X_flag,Y_flag;
int j;
float dx, dy;
char RxBuffer[RX_BUFFER_SIZE];  			// 接收数据的缓冲区
volatile uint8_t RxIndex = 0;  			// 接收数据的索引
float popx=0, popy=30 ,a0,a1,num1,num2;
// 串口接收状态机定义
typedef enum 
{
    STATE_WAIT_HEADER,          		//等待帧头
    STATE_RECEIVE_DATA,         		// 接收数据部分
    STATE_WAIT_TAIL           		// 等待帧尾
} ReceiveState;

ReceiveState state = STATE_WAIT_HEADER;   // 当前接收状态
uint8_t data_received = 0;    				// 接受完数据帧标志位
//uint16_t CALIB_OBJECT_WIDTH_PIXEL;      // A4纸在图像中的宽度（像素）
//uint16_t CALIB_OBJECT_HEIGHT_PIXEL;     // A4纸在图像中的高度（像素）

// 屏幕尺寸和中心坐标
#define SCREEN_WIDTH  320
#define SCREEN_HEIGHT 240
#define SCREEN_CENTER_X (SCREEN_WIDTH / 2)   // 中心X = 160
#define SCREEN_CENTER_Y (SCREEN_HEIGHT / 2)  // 中心Y = 120

// 舵机角度限制（根据实际舵机调整）
#define HORIZONTAL_MIN_ANGLE -180  // 水平最小角度（左极限）
#define HORIZONTAL_MAX_ANGLE 180  // 水平最大角度（右极限）
#define VERTICAL_MIN_ANGLE -90    // 垂直最小角度（下极限）
#define VERTICAL_MAX_ANGLE 90     // 垂直最大角度（上极限）
// 使用串口1作为舵机控制的端口
// <接线说明>
// STM32F103 PA9(Tx)    <----> 总线伺服舵机转接板 Rx
// STM32F103 PA10(Rx)   <----> 总线伺服舵机转接板 Tx
// STM32F103 GND        <----> 总线伺服舵机转接板 GND
// STM32F103 V5         <----> 总线伺服舵机转接板 5V9
// <注意事项>
// 使用前确保已设置usart.h里面的USART1_ENABLE为1
Usart_DataTypeDef* servo_usart = &usart1; 

// 使用串口2作为日志输出的端口
// <接线说明>
// STM32F103 PA2(Tx) <----> USB转TTL Rx
// STM32F103 PA3(Rx) <----> USB转TTL Tx
// STM32F103 GND     <----> USB转TTL GND
// STM32F103 V5      <----> USB转TTL 5V (可选)
Usart_DataTypeDef* logging_usart = &usart2;

// 重定向c库函数printf到串口，重定向后可使用printf函数
int fputc(int ch, FILE *f)
{
    while((logging_usart->pUSARTx->SR&0X40)==0){}
    /* 发送一个字节数据到串口 */
    USART_SendData(logging_usart->pUSARTx, (uint8_t) ch);
    /* 等待发送完毕 */
    // while (USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET);       
    return (ch);
}

// 串口接收中断处理函数
void USART2_IRQHandler(void) 
	{
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) 
			{
						
        uint8_t received = USART_ReceiveData(USART2);  // 接收数据

        switch (state) 
			  {
            case STATE_WAIT_HEADER:      // 等待帧头
                if (received == 0x2D)    // 检测到帧头
						 {  
                    state = STATE_RECEIVE_DATA;//设置状态为开始接收数据
                    RxIndex = 0;
						 }
                break;

            case STATE_RECEIVE_DATA:     // 开始接收数据
                if (received == 0x5C)    // 检测到帧尾
						 { 
                    state = STATE_WAIT_TAIL; //设置状态为等待帧尾
                    data_received = 1;       //接收完数据标志位置1
						 } 
					 else 
						 {
                    if (RxIndex < RX_BUFFER_SIZE - 1) 
							  {
                        RxBuffer[RxIndex++] = received;  //如果接收到的数据不是桢尾，那就一直把数据存在缓冲区里
                       }
                   }
                break;

            case STATE_WAIT_TAIL:			   //接收到等待帧尾就重新设置为等待帧头，如此循环接收
                if (received == 0x5C) 
					    {
                    state = STATE_WAIT_HEADER; 
                   } 
					 else 
						 {
                    state = STATE_WAIT_HEADER;
                   }
                break;							
					
				
				
				
				
				}
				
				USART_ClearITPendingBit(USART2, USART_IT_RXNE);  // 清除中断标志
		
				
				
		
         }
   }


		
// 处理接收到的数据
void Process_Received_Data(void) 
{
    			if (data_received) 
						{
								flag1=1;
								if (RxIndex >=8 ) 
								{                 									
										dx = (RxBuffer[0] << 8) | RxBuffer[1];    // 解析x坐标（2字节合成）										
										dy = (RxBuffer[2] << 8) | RxBuffer[3];    // 解析y坐标（2字节合成）												
									      									
											//	dx = (RxBuffer[4] << 8) | RxBuffer[5];
											//	dy = (RxBuffer[6] << 8) | RxBuffer[7];
										num1= (RxBuffer[4] << 8) | RxBuffer[5];
										num2= (RxBuffer[6] << 8) | RxBuffer[7];		
												
								}
					   }
			// 重置状态
        data_received = 0;
        RxIndex = 0;
        state = STATE_WAIT_HEADER;
				
}


// 标定参数（通过实际测量确定）
#define CALIB_OBJECT_WIDTH_CM    23.0f  // A4纸宽度（cm）
#define CALIB_OBJECT_HEIGHT_CM   31.7f  // A4纸高度（cm）

// 计算比例因子
#define SCALE_X (CALIB_OBJECT_WIDTH_PIXEL / CALIB_OBJECT_WIDTH_CM)    // 像素/cm
#define SCALE_Y (CALIB_OBJECT_HEIGHT_PIXEL / CALIB_OBJECT_HEIGHT_CM)  // 像素/cm

// 摄像头和激光笔的位置偏差（像素单位）
#define CAMERA_LASER_OFFSET_X (0.0f * SCALE_X)  // 水平方向偏差（像素）
#define CAMERA_LASER_OFFSET_Y (0.0f * SCALE_Y)  // 垂直方向偏差（像素）



int keynum=0;
int main(void)
{
    
    // 系统初始化
    SysTick_Init();
	 Key_Init();
    Usart_Init();
    OLED_Init();
    //Button_Init();  // 初始化按钮中断
    Laser_Init();
	 SysTick_CountdownBegin(2200);  // 参数单位：ms，2000ms=2秒

	 while (1)
    {		
			isTimeUp = 0;
			Process_Received_Data();  // 处理串口数据
		   keynum=Key_GetNum();
		   /*
			  if(flag)
			  {
					flag1=0;
					two();
			  }
			*/
		    switch(keynum)
			{
				//第二问
				case 1:
			  {			
					
						//	Process_Received_Data();  // 处理串口数据
												
								two();
											
					break;
				} 
								
					
				//第三问	
			  case 2:
			  {							
				   
						Process_Received_Data();  // 处理串口数据
								if(flag1)						
								{
									flag1=0;
									two ();
								}
								else
								{							
									FSUS_SetServoAngle(servo_usart, 0, 0,0, 0);
									FSUS_SetServoAngle(servo_usart, 1, 27,0, 0);  
									for( j=1;j<=10;j++)
									{			
										Process_Received_Data();   // 处理串口数据
										FSUS_SetServoAngle(servo_usart, 0, 6*j,100, 0);
										SysTick_DelayMs(70);														
										if(flag1)
										{
											flag1=0;
											two ();							
										}							
									}
										//	SysTick_DelayMs(500);		
										if(1)
										{
																	 /*								
																for( j=60;j<=-60;j-=6)
																	{			
																		Process_Received_Data();  // 处理串口数据	
																		FSUS_SetServoAngle(servo_usart, 0, j,100, 0);
																		SysTick_DelayMs(70);															
																		if(flag1)
																		{
																			flag1=0;
																			two ();
																		}
									
																	}*/				
																				
												FSUS_SetServoAngle(servo_usart, 0, 30,800, 0);
												SysTick_DelayMs(200);
												Process_Received_Data();  // 处理串口数据	
												if(flag1)
												{
												   flag1=0;
													two ();
												}
												FSUS_SetServoAngle(servo_usart, 0, 0,800, 0);
											   SysTick_DelayMs(200);
												Process_Received_Data();  // 处理串口数据	
												if(flag1)
												{
													flag1=0;
													two ();
												}
												FSUS_SetServoAngle(servo_usart, 0, -30,800, 0);
												SysTick_DelayMs(200);
												Process_Received_Data();  // 处理串口数据	
												if(flag1)
												{
													flag1=0;
													two ();
												}
												FSUS_SetServoAngle(servo_usart, 0, -60,800, 0);
												SysTick_DelayMs(200);
												Process_Received_Data();  // 处理串口数据	
												if(flag1)
												{
													flag1=0;
													two ();
												}
																						
										}
				
														
								}//else
							break;
				}//case
			}//switch

				

    }//while
	
	
}//main
