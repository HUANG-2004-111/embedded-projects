#include "stm32f10x.h"                  // Device header
#include "sys_tick.h"
#include "sys_tick.h"
#include "fashion_star_uart_servo.h"
#include "OLED.h"
#include "key.h"
#include "fashion_star_uart_servo.h"
extern Usart_DataTypeDef* servo_usart;
extern uint8_t isTimeUp,IsTimeUp,flag; 
extern float num1,popx,dx,dy,num2,popy;
void two (void)
{
		if (!isTimeUp)
					 {					 										 
						if(dx>= 70)
							{						  
								if(num1 == 4)popx+=0.35;
								if(num1 == 6)popx-=0.35;
							}
						else if(dx < 70 && dx >= 48)
						{
							
							 if(num1 == 4)popx+=0.25;
						    if(num1 == 6)popx-=0.25;
						}
						else
						{
						    
							if(dx<= 3)
							{
							   if(num1 == 4)popx+=0.0;
							   if(num1 == 6)popx-=0.0;
							}
							else
							{
							   if(dx < 48 && dx >= 20)
							   {
									if(num1 == 4)
										popx+=0.15;
									if(num1 == 6)
										popx-=0.15;
							    }
							   else
								{
									if(num1 == 4)
										popx+=0.025;
									if(num1 == 6)
										popx-=0.025;
								}
							}
					
						}							
						if(dy>= 70)
						{
							
							if(num2 == 2)
								popy-=0.35;
							if(num2 == 8)
								popy+=0.35;
						}
						else if(dy < 70 && dy >= 48)
						{
							
							if(num2 == 2)
								popy-=0.25;
							if(num2 == 8)
								popy+=0.25;
						}
						else
						{
							if(dy<= 3)
							{
								if(num2 == 2)
									popy-=0.0;
								if(num2 == 8)
									popy+=0.0;
							}
							else
							{
								if(dy < 48 && dy >= 20)
								{
									if(num2 == 2)
										popy-=0.15;
									if(num2 == 8)
										popy+=0.15;
								}
								else
								{
									if(num2 == 2)
										popy-=0.025;
									if(num2 == 8)
										popy+=0.025;
							     }
							}
						}			
			
					if(dx<=3 && dy>3)
					    {
							FSUS_SetServoAngle(servo_usart, 1, popy,0, 0);  									
						 }
					if(dy<=3 && dx>3)
						{
							FSUS_SetServoAngle(servo_usart, 0, popx,0, 0);  	
						}
					if(dx >3 && dy >3)
							{
								FSUS_SetServoAngle(servo_usart, 0, popx,0, 0);
								FSUS_SetServoAngle(servo_usart, 1, popy,0, 0);  
							}
				
				//	OLED_ShowNum(1, 1,dx,5);//��ʾ0�Ŷ���Ƕ�           
			   //	OLED_ShowNum(2, 1,dy,5); //��ʾ1�Ŷ���Ƕ�
				//	OLED_ShowNum(3, 1, popx,5);//��ʾ0�Ŷ���Ƕ�           
				//	OLED_ShowNum(4, 1, popy,5); //��ʾ1�Ŷ���Ƕ�
					}
					 
					
					  if (!isTimeUp && SysTick_CountdownIsTimeout())
							{
										isTimeUp = 1;  // ���ʱ���ѵ�����ֹ�ظ�ִ��
				
										// 1. ֹͣ��������͵�ǰ�Ƕȣ�����λ�ã�	
										FSUS_SetServoAngle(servo_usart, 0, popx, 0, 0);
										FSUS_SetServoAngle(servo_usart, 1, popy, 0, 0);
									
											// 2. ��������ʣ�PA6��0��
											GPIO_SetBits(GPIOA, GPIO_Pin_6);
											SysTick_DelayMs(5000);
						
							}
						












}