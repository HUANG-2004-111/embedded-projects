import sensor
import time
import image
from machine import UART  # 导入串口模块
import math

# 初始化串口通信（根据实际接线选择UART端口和波特率）
uart = UART(3, baudrate=115200, timeout_char=0)

# 定义为彩色模式
gray_mode = False  # 改为False表示彩色模式

# 摄像头初始化 - 彩色模式
sensor.reset()
sensor.set_pixformat(sensor.RGB565)     # 使用彩色模式
sensor.set_auto_gain(False)             # 关闭自动增益
sensor.set_auto_whitebal(False)         # 关闭自动白平衡
sensor.set_framesize(sensor.QQVGA)      # 设置为QQVGA分辨率

sensor.set_brightness(0)                # 降低亮度
sensor.set_contrast(0)                  # 对比度设置
sensor.set_auto_exposure(True)          # 开启自动曝光，删除手动曝光时间参数


# 镜头畸变校正系数，根据实际情况调整
lens_correction_strength = 1.4

clock = time.clock()

# 绘制矩形函数
def draw_rectangle(corners, color):
    """在图像上绘制矩形，corners为矩形的四个顶点"""
    img.draw_line(corners[0][0], corners[0][1], corners[1][0], corners[1][1], color, 2)
    img.draw_line(corners[1][0], corners[1][1], corners[2][0], corners[2][1], color, 2)
    img.draw_line(corners[2][0], corners[2][1], corners[3][0], corners[3][1], color, 2)
    img.draw_line(corners[3][0], corners[3][1], corners[0][0], corners[0][1], color, 2)

# 简化的矩形中心坐标计算（直接通过矩形边界计算，无需遍历角点）
def calculate_center(rect):
    x, y, w, h = rect           # rect为(r.rect())返回的(x, y, 宽, 高)
    center_x = x + w // 2       # 整数除法减少计算量
    center_y = y + h // 2
    return (center_x, center_y)

# 发送dx、dy、num1和num2到STM32
def send_dx_dy_num1_num2_to_stm32(dx, dy, num1, num2):
    data = bytearray([0x2D])        # 帧头
    data.append(int(dx) >> 8)       # dx高字节
    data.append(int(dx) & 0xFF)     # dx低字节
    data.append(int(dy) >> 8)       # dy高字节
    data.append(int(dy) & 0xFF)     # dy低字节
    data.append(int(num1) >> 8)     # num1高字节
    data.append(int(num1) & 0xFF)   # num1低字节
    data.append(int(num2) >> 8)     # num2高字节
    data.append(int(num2) & 0xFF)   # num2低字节
    data.append(0x5C)               # 帧尾
    uart.write(data)

# 彩色模式下的绘图颜色定义
red = (255, 0, 0)                   # 红色（用于绘制有效矩形）
white = (255, 255, 255)             # 白色（用于帧率显示）

# 屏幕中心点坐标
screen_center_x = 77.5
screen_center_y = 62.5


# 主循环
while True:
    clock.tick()
    img = sensor.snapshot()
    img.lens_corr(lens_correction_strength)     # 镜头畸变校正

    rect_detected = False
    # 基础矩形识别（仅过滤面积和长宽比）
    for r in img.find_rects(threshold=150):
        if r.magnitude() > 8000:                # 过滤小矩形
            rect = r.rect()                     # 获取矩形边界 (x, y, 宽, 高)
            w, h = rect[2], rect[3]
            if w == 0 or h == 0:
                continue                        # 避免除零错误

            # 计算长宽比（取较大值/较小值，确保比例≥1）
            aspect_ratio = max(w, h) / min(w, h)
            # 判断长宽比是否接近1.4（允许±0.1误差）
            if 1.3 <= aspect_ratio <= 1.6:
                corners = r.corners()            # 获取四个角点坐标

                # 用红线绘制有效矩形和角点
                draw_rectangle(corners, color=red)
                for p in corners:
                    img.draw_circle(p[0], p[1], 5, color=red)

                # 计算中心坐标（简化版）
                center_x, center_y = calculate_center(rect)
                img.draw_circle(center_x, center_y, 5, color=red)

                # 获取矩形宽高并显示
                img.draw_string(center_x - 20, center_y - 15, f"W: {w}, H: {h}", color=red)

                # 计算dx、dy和方向参数
                dx = screen_center_x - center_x
                dy = screen_center_y - center_y
                num1 = 4 if dx < 0 else 6
                num2 = 2 if dy < 0 else 8
                dx = abs(dx)
                dy = abs(dy)

                # 发送数据到STM32
                send_dx_dy_num1_num2_to_stm32(dx, dy, num1, num2)
                rect_detected = True

                # 调试信息
                print("中心坐标:", (center_x, center_y))
                print("dx/dy:", dx, dy)
                print("num1/num2:", num1, num2)
                break  # 只处理第一个有效矩形

    # 未检测到有效矩形时发送提示
    if not rect_detected:
        uart.write("NO_RECT#\n".encode())

    # 显示帧率
    img.draw_string(10, 10, f"FPS: {clock.fps():.2f}", color=white)
